﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assessment2_38008149
{
    public partial class Hotelbook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["rbone"] = "HotelF1 Paris Saint Denis Stade";
            Session["rbtwo"] = "Ibis Paris Saint-Denis Stade Sud";
            Session["rbthree"] = "Courtyard by Marriott Paris Saint Denis";
            

        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(RadioButton1.Checked)
            {
                Response.Redirect("Hotel1.aspx");
            }
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (RadioButton2.Checked)
            {
                Response.Redirect("Hotel2.aspx");
            }
        }

        protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (RadioButton3.Checked)
            {
                Response.Redirect("Hotel3.aspx");
            }
        }
    }
}