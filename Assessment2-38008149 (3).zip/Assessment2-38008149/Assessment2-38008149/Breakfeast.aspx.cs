﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing.Printing;

namespace Assessment2_38008149
{
    
    public partial class Breakfeast : System.Web.UI.Page
    {
        string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Visual Studios\Assessment2-38008149\Assessment2-38008149\App_Data\Database1.mdf;Integrated Security = True";
        public SqlConnection con;
        public SqlCommand command;
        public SqlDataAdapter adpter;
        public DataSet ds;
        //public DataBinder ds;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
            HttpCookie _userCookie = new HttpCookie("UserInformation");
            _userCookie.Expires = DateTime.Now.AddDays(5);
            _userCookie["UserLogIn"] = TextBox1.Text;
            _userCookie["UserPasswHint"] = TextBox2.Text;
            _userCookie["email"] = TextBox4.Text;
            _userCookie["number"] = TextBox5.Text;
            _userCookie["days staying"] = TextBox8.Text;
            _userCookie["team"] = TextBox10.Text;
           
        }
        public void ShowDataGrid()
        {

            con = new SqlConnection(conStr);
            string sql = "SELECT * FROM Hoteltable";
            con.Open();
            ds = new DataSet();
            adpter = new SqlDataAdapter();
            command = new SqlCommand(sql, con);
            adpter.SelectCommand = command;
            adpter.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();



        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ShowDataGrid();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string name = TextBox2.Text;
            string surname = TextBox3.Text;
            string Hotel = DropDownList1.SelectedValue;
            string breakfeast = TextBox7.Text;
            string team = TextBox10.Text;
            string email = TextBox4.Text;

            if (int.TryParse(TextBox1.Text, out int vin))
            {
                if (int.TryParse(TextBox8.Text, out int year))
                {
                    if (int.TryParse(TextBox9.Text, out int night))
                    {
                        if (int.TryParse(TextBox5.Text, out int cell))
                        {
                            //if (DropDownList1.SelectedIndex != -1)
                            //{
                                //string type = DropDownList1.SelectedItem.ToString();

                                string sql = $"INSERT INTO Hoteltable(Id, Name, Surname, Hotel_picked, NO_of_days_staying, Breakfeast, No_of_guests, Champ_final, cell_NO, email) VALUES({vin}, '{name}', '{surname}','{Hotel}','{year}','{breakfeast}','{night}','{team}', '{cell}', '{email}')";
                            con = new SqlConnection(conStr);
                            con.Open();

                                command = new SqlCommand(sql, con);

                                adpter = new SqlDataAdapter();
                                adpter.InsertCommand = command;
                                adpter.InsertCommand.ExecuteNonQuery();

                                con.Close();
                                //MessageBox.Show("Data successfully inserted");
                                ShowDataGrid();

                                //vinTextBox.Clear();
                                //brandTextBox.Clear();
                                //modelTextBox.Clear();
                                //yearTextBox.Clear();
                                //typeComboBox.SelectedIndex = -1;
                            //}
                        }
                    }
                    /* else
                     {
                         MessageBox.Show("Choose a Vehicle Type");
                     }
                 }
                 else
                 {
                     MessageBox.Show("Enter a valid year");
                 }
             }
             else
             {
                 MessageBox.Show("Enter a valid Vin number");
             }*/
                }
            }
            

            
        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Thankyou.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            HttpCookie _userCookieRetreive = Request.Cookies["UserLogIn"];
            HttpCookie _userCookieRetreive1 = Request.Cookies["UserPasswHint"];
            //HttpCookie _userCookieRetreive2 = Request.Cookies["UserPasswHint"];
            HttpCookie _userCookieRetreive3 = Request.Cookies["email"];
            HttpCookie _userCookieRetreive4 = Request.Cookies["number"];
            HttpCookie _userCookieRetreive5 = Request.Cookies["days staying"];
            HttpCookie _userCookieRetreive6 = Request.Cookies["team"];

            if (_userCookieRetreive != null && _userCookieRetreive1 != null && _userCookieRetreive3 != null && _userCookieRetreive4 != null && _userCookieRetreive5 != null && _userCookieRetreive6 != null)                   //if the cookie is not empty
            {
                lblDisplay.Text = "Thank you for adding your details " + _userCookieRetreive["UserLogIn"] + " " + _userCookieRetreive1["UserPasswHint"] + "the following page will be the payment page and if you wish to purchase one of our packages we will send you a booking confirmation to " + _userCookieRetreive3["email"] + ",you will be staying at you desired hotel for " + _userCookieRetreive4["number"] + "days we also want to wish you a happy stay in france and hope " + _userCookieRetreive6["team"] + " wins the final";
            }
        }
    }
}