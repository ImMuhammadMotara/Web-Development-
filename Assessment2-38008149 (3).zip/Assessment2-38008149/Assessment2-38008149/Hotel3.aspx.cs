﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assessment2_38008149
{
    public partial class Hotel3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            DateTime myDate = Calendar1.SelectedDate;
            if (Calendar1 != null)
            {
                Label5.Text = "";
                Label5.Text = myDate.ToString("dddd, yyyy,MM,dd");
                Label5.Text = "";
                Label5.Text = myDate.ToString("dddd, yyyy,MM,dd");
            }
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            DateTime myDate = Calendar2.SelectedDate;
            if (Calendar2 != null)
            {
                Label5.Text = "";
                Label5.Text = myDate.ToString("dddd, yyyy,MM,dd");
                Label5.Text = "";
                Label5.Text = myDate.ToString("dddd, yyyy,MM,dd");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Breakfeast.aspx");
        }
    }
}