﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing.Printing;

namespace Assessment2_38008149
{
    public partial class Thankyou : System.Web.UI.Page
    {
        string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Visual Studios\Assessment2-38008149\Assessment2-38008149\App_Data\Database1.mdf;Integrated Security = True";
        public SqlConnection con;
        public SqlCommand command;
        public SqlDataAdapter adpter;
        public DataSet ds;
        //public DataBinder ds;

        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(conStr);
            string sql = "SELECT * FROM Hoteltable";
            con.Open();
            ds = new DataSet();
            adpter = new SqlDataAdapter();
            command = new SqlCommand(sql, con);
            adpter.SelectCommand = command;
            adpter.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
            con.Close();



        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Session["rbone"] != null)
            {
                
                Label1.Text = "Thank you for flying fly Moti the total amount is R1500 we have also provided you with a brief summary to help you confirm if all your details are correct if you wish to change anythiing press the link at the bottom to redirect back to the details page, press the pay button below to confirm you purchase";
            }
            if (Session["rbtwo"] != null)
            {

                Label1.Text = "Thank you for flying fly Moti the total amount is R2500 we have also provided you with a brief summary to help you confirm if all your details are correct if you wish to change anythiing press the link at the bottom to redirect back to the details page, press the pay button below to confirm you purchase";
            }
            else
            {
                
                Label1.Text = "Thank you for flying fly Moti the total amount is R2000 we have also provided you with a brief summary to help you confirm if all your details are correct if you wish to change anythiing press the link at the bottom to redirect back to the details page, press the pay button below to confirm you purchase";
                
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Label1.Text = "Thank you for your purchase we have sent you a Booking Confirmation on your email, Thank you for using FlyMoti we hope to see you again and Enjoy the Champions Legue Final!!!!=)"; 
        }

        protected void Button3_Click(object sender, EventArgs e)
        {

            

        }
    }
}